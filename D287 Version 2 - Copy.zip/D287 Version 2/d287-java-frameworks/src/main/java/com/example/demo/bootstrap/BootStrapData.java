package com.example.demo.bootstrap;

import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository = outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

       /*
        OutsourcedPart o= new OutsourcedPart();
        o.setCompanyName("Western Governors University");
        o.setName("out test");
        o.setInv(5);
        o.setPrice(20.0);
        o.setId(100L);
        outsourcedPartRepository.save(o);
        OutsourcedPart thePart=null;
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            if(part.getName().equals("out test"))thePart=part;
        }

        System.out.println(thePart.getCompanyName());
        */

        //Part E. added sample inventory. created 5 parts
        if (outsourcedPartRepository.count() == 0) {

            OutsourcedPart lipgloss = new OutsourcedPart();
            lipgloss.setCompanyName("Western Governors University");
            lipgloss.setName("lip gloss");
            lipgloss.setInv(5);
            //Part G.min and max fields
            lipgloss.setMaxInventory(20);
            lipgloss.setMinInventory(0);
            lipgloss.setPrice(4.0);
            lipgloss.setId(100L);
            outsourcedPartRepository.save(lipgloss);
            OutsourcedPart thePart = null;

            OutsourcedPart charm = new OutsourcedPart();
            charm.setCompanyName("Western Governors University");
            charm.setName("charm");
            charm.setInv(5);
            //Part G.min and max fields
            charm.setMaxInventory(20);
            charm.setMinInventory(0);
            charm.setPrice(4.0);
            charm.setId(150L);
            outsourcedPartRepository.save(charm);

            OutsourcedPart scarf = new OutsourcedPart();
            scarf.setCompanyName("Western Governors University");
            scarf.setName("scarf");
            scarf.setInv(5);
            //Part G.min and max fields
            scarf.setMaxInventory(20);
            scarf.setMinInventory(0);
            scarf.setPrice(12.0);
            scarf.setId(130L);
            outsourcedPartRepository.save(charm);

            OutsourcedPart nails = new OutsourcedPart();
            nails.setCompanyName("Western Governors University");
            nails.setName("nails");
            nails.setInv(5);
            //Part G.min and max fields
            nails.setMaxInventory(20);
            nails.setMinInventory(0);
            nails.setPrice(9.0);
            nails.setId(180L);
            outsourcedPartRepository.save(charm);

            OutsourcedPart socks = new OutsourcedPart();
            socks.setCompanyName("Western Governors University");
            socks.setName("socks");
            socks.setInv(5);
            //Part G.min and max fields
            socks.setMaxInventory(20);
            socks.setMinInventory(0);
            socks.setPrice(6.0);
            socks.setId(151L);
            outsourcedPartRepository.save(charm);
        }
        List<OutsourcedPart> outsourcedParts = (List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for (OutsourcedPart part : outsourcedParts) {
            System.out.println(part.getName() + " " + part.getCompanyName());
        }

        if (productRepository.count() == 0) {

        //Part E. created 5 products
            Product shirt = new Product("shirt", 20.0, 15);
            Product pants = new Product("pants", 30.0, 15);
            Product plush = new Product("plush", 15.0, 15);
            Product bracelet = new Product("bracelet", 20.0, 15);
            Product purse = new Product("purse", 40.0, 15);
            productRepository.save(shirt);
            productRepository.save(pants);
            productRepository.save(plush);
            productRepository.save(bracelet);
            productRepository.save(purse);



        /*
        Product bicycle= new Product("bicycle",100.0,15);
        Product unicycle= new Product("unicycle",100.0,15);
        productRepository.save(bicycle);
        productRepository.save(unicycle);
        */

            System.out.println("Started in Bootstrap");
            System.out.println("Number of Products" + productRepository.count());
            System.out.println(productRepository.findAll());
            System.out.println("Number of Parts" + partRepository.count());
            System.out.println(partRepository.findAll());

        }
    }
}
