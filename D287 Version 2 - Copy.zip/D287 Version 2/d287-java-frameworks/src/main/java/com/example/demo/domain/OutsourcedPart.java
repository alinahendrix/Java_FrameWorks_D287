package com.example.demo.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 *
 *
 *
 */
@Entity
@DiscriminatorValue("2")
public class OutsourcedPart extends Part{
String companyName;

    public OutsourcedPart() {
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    //Part G. created text inputs
    int maxInventory;
    public int getMaxInventory() {
        return maxInventory;
    }
    public void setMaxInventory(int maxInventory) {
        this.maxInventory = maxInventory;
    }

    int minInventory;
    public int getMinInventory() {
        return minInventory;
    }
    public void setMinInventory(int minInventory) {
        this.minInventory = minInventory;
    }
    //end text inputs
}
